#!/usr/bin/env python
import numpy as np
import rospy
from std_msgs.msg import String
from tt5_ros.msg import SixRodOrientation
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders
from tt5_ros.msg import SixRodMotorCommands

import control

def acceleration_callback(data):
    x = 5
    print(data)

    # GPS.update(data)
    ### PASS ACCELERATION DATA BACK TO GPS

def motorCommandToArray(sixRodMC):
    command = [0]*24
    rods = [
        sixRodMC.rod1,
        sixRodMC.rod2,
        sixRodMC.rod3,
        sixRodMC.rod4,
        sixRodMC.rod5,
        sixRodMC.rod6,
        ]
    for i in range(len(rods)):
        rod = rods[i]
        command[4 * i] = rod.motor1
        command[4 * i + 1] = rod.motor2
        command[4 * i + 2] = rod.motor3
        command[4 * i + 3] = rod.motor4
    control.batch_motor_controls(command)

def motor_callback(data):
    #print(type(data))
    motorCommandToArray(data)
    #data = list(motorCommandToArray(data))
    #control.batch_motor_controls(data)

def listener():

    rospy.init_node('Master_Side_Listener', anonymous=True)

    rospy.Subscriber('Motor_Commands', SixRodMotorCommands, motor_callback)
    rospy.Subscriber('Accelerations', SixRodAcceleration, acceleration_callback)
    

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
