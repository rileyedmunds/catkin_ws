#!/usr/bin/env python
import rospy
from std_msgs.msg import String
from tt5_ros.msg import SixRodMotorCommands
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders
from tt5_ros.msg import MotorCommands
import sys
import threading
import argparse #used to get the COM port and the number of motors
try:
    import Queue as queue
except:
    import queue
import time

#next lines are needed so that the wireless library can be imported from relative path
import os
#direct path of this python file needs to be explicitly defined, so rosrun can be called from any directory 
dir_path = os.path.dirname(os.path.realpath(__file__))
import sys
# sys.path.append(dir_path+'/../../../../wireless/lib/tensegrity_wireless/py')
sys.path.append('/home/jianlan//Spherical-Tensegrity/wireless/lib/tensegrity_wireless/py/')
from controller import Controller
import control
import message_writer as mw
import state_manager
import serial
try:
    import Queue as queue
except:
    import queue

last_line = ''
SimulatedSensors = False
controllers = control.get_controllers()
#send_down = queue.Queue()

def talker():

    rospy.init_node('talker', anonymous=True)
    
    #rod accelerations
    acceleration_pub = rospy.Publisher('Accelerations', SixRodAcceleration, queue_size=100)
    # motor_pub = rospy.Publisher('Motor_Commands', SixRodMotorCommands, queue_size=1)

    rate = rospy.Rate(10) # 10hz

    #continuously update and publish
    while not rospy.is_shutdown():


        Acceleration_Vec = update_Accelerations()
        print('published acceleration', Acceleration_Vec)

        acceleration_pub.publish(Acceleration_Vec)

        # Motor_Commands_Vec = update_Motors()
        # motor_pub.publish(Motor_Commands_Vec)
        
        rate.sleep()
        print(rospy.is_shutdown())

############################################################################


def keep_last_line():
    global last_line, new_line_event
    for line in sys.stdin:
        #need 'last_line' for each sensor group
        #last_line emulates the state_managers latest readings
        if 'Simulated_Orientation_Sensors' in line:
            last_line = line
        
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def update_Accelerations():
    Acceleration_Vec = SixRodAcceleration()
    # measurements = control.get_encoder_reading()
    for c in controllers:
        rod_num = str(c.get_id())
        rod_accel = getattr(Acceleration_Vec,'rod'+rod_num)
        [rod_accel.x,rod_accel.y,rod_accel.z] = c.get_imu()
    # print(Acceleration_Vec, '      =acceleration vec')    
    return Acceleration_Vec

def update_Motors():
    motor_vec = SixRodMotorCommands()
    commands = [0]*24 ### GET COMMANDS FROM GPS
    motor_command = SixRodMotorCommands()
    rods = [
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        ]
    for i in range(len(rods)):
        rod = rods[i]
        rod.motor1 = commands[4 * i]
        rod.motor2 = commands[4 * i + 1]
        rod.motor3 = commands[4 * i + 2]
        rod.motor4 = commands[4 * i + 3]
        setattr(motor_command, 'rod' + str(i+1), rod)
    return motor_command

if __name__ == '__main__':
    print('Starting Xbee-side ROS node...')

    if(SimulatedSensors!=True):

        """ Initializes the variable for the queue of messages that are being sent 'down'. """
        # send_down = control.get_send_down()
        global send_down
        sm, send_down = control.get_sm_queue()

        #Ensure commucation between Xbees is established
        Xbee_ready = False
        while(Xbee_ready==False):
            Xbee_ready = True
            print("Requesting echoes...")
            for c in controllers:
                # print(c.get_echo(), '    echooo')
                m = mw.write_echo(c.get_echo() + 1)
                c.start_echo()
                send_down.put([c, m]) ###THIS LINE CAUSING THE __TRUNC__ ERROR
                time.sleep(.05)


                # msg = [0,0,0,0]
                # message = mw.write_motor_command(msg)
                # print(c,message, '     c, message')
                # send_down.put([c, message])

                time.sleep(.05)


            time.sleep(.2) # wait 2s for replies
            print('slept .2 seconds')
            for c in controllers:

                print(str(c.get_id())+': '+ str(c.connected))
                if c.connected==False:
                    Xbee_ready = True 
                    print('Xbee ready')       

    try:
        print('running talker()')
        talker()
    except rospy.ROSInterruptException:
        pass

        
    