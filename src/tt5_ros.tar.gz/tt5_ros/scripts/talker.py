#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Vector3
from tt5_ros.msg import SixRodOrientation
from tt5_ros.msg import SixRodMotorCommands
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders
import sys
import threading
import argparse #used to get the COM port and the number of motors
try:
    import Queue as queue
except:
    import queue
import time

#next lines are needed so that the wireless library can be imported from relative path
import os
#direct path of this python file needs to be explicitly defined, so rosrun can be called from any directory 
dir_path = os.path.dirname(os.path.realpath(__file__))
import sys
sys.path.append(dir_path+'/../../../../wireless/lib/tensegrity_wireless/py')
from controller import Controller
import message_writer as mw
import state_manager
import serial



last_line = ''
SimulatedSensors = False

def talker():

    #used for parsing std::cin
    if(SimulatedSensors):
        keep_last_line_thread = threading.Thread(target=keep_last_line)
        keep_last_line_thread.daemon = True
        keep_last_line_thread.start()

    rospy.init_node('talker', anonymous=True)
    
    #rod orientation 

    orientation_pub = rospy.Publisher('Rod_Orientations', SixRodOrientation, queue_size=1000)
    #rod accelerations
    acceleration_pub = rospy.Publisher('Accelerations', SixRodAcceleration, queue_size=1000)
    #rod encoders
    encoder_pub = rospy.Publisher('Encoders', SixRodEncoders, queue_size=1000)

    
    rate = rospy.Rate(10) # 10hz

    #continuously update and publish
    while not rospy.is_shutdown():

        #Orientation_Vec = update_Orientations()
        #rospy.loginfo(getattr(Orientation_Vec,"rod1")) #debugging purposes
        #orientation_pub.publish(Orientation_Vec)

        Acceleration_Vec = update_Accelerations()
        acceleration_pub.publish(Acceleration_Vec)
        
        Encoder_Vec = update_Encoders()
        encoder_pub.publish(Encoder_Vec)
        
        rate.sleep()

############################################################################


def keep_last_line():
    global last_line, new_line_event
    for line in sys.stdin:
        #need 'last_line' for each sensor group
        #last_line emulates the state_managers latest readings
        if 'Simulated_Orientation_Sensors' in line:
            last_line = line
        
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def update_Orientations():
    Orientation_Vec = SixRodOrientation()
    if(SimulatedSensors):
        if 'Simulated_Orientation_Sensors' in last_line:
            line = last_line
            line =  line.strip().split(',')
            print line
            #print 'Extracted Theta Information:'
            Orientation_Vec.rod1.z = float(line[6]);
            Orientation_Vec.rod2.z = float(line[7]);
            Orientation_Vec.rod3.z = float(line[8]);
            Orientation_Vec.rod4.z = float(line[9]);
            Orientation_Vec.rod5.z = float(line[10]);
            Orientation_Vec.rod6.z = float(line[11]);
            #print 'Extracted Phi Information:'
            Orientation_Vec.rod2.x = float(line[1]);
            Orientation_Vec.rod3.x = float(line[2]);
            Orientation_Vec.rod4.x = float(line[3]);
            Orientation_Vec.rod5.x = float(line[4]);
            Orientation_Vec.rod6.x = float(line[5]);
    return Orientation_Vec

def update_Accelerations():
    Acceleration_Vec = SixRodAcceleration()
    if(SimulatedSensors):
        print('placeholder')
    else:
        for c in controllers:
            rod_num = str(c.get_id())
            rod_accel = getattr(Acceleration_Vec,'rod'+rod_num)
            [rod_accel.x,rod_accel.y,rod_accel.z] = c.get_imu()

            #FOR DEBUGGING 
            if(isinstance(rod_accel.x,float)!=True):
                rod_accel.x = -1
            if(isinstance(rod_accel.y,float)!=True):
                rod_accel.y = -1
            if(isinstance(rod_accel.z,float)!=True):
                rod_accel.z = -1
            
    return Acceleration_Vec

def update_Encoders():
    Encoder_Vec = SixRodEncoders()
    if(SimulatedSensors):
        print('placeholder')
    else:
        for c in controllers:
            rod_num = str(c.get_id())

            rod_encoders = getattr(Encoder_Vec,'rod'+rod_num)
            [rod_encoders.encoder1,rod_encoders.encoder2,rod_encoders.encoder3,rod_encoders.encoder4] = c.get_encoder()
            if(isinstance(rod_encoders.encoder1,int)!=True):
                rod_encoders.encoder1 = -1
            if(isinstance(rod_encoders.encoder2,int)!=True):
                rod_encoders.encoder2 = -1
            if(isinstance(rod_encoders.encoder3,int)!=True):
                rod_encoders.encoder3 = -1
            if(isinstance(rod_encoders.encoder4,int)!=True):
                rod_encoders.encoder4 = -1

    return Encoder_Vec


if __name__ == '__main__':
    print('Starting Xbee-side ROS node...')

    if(SimulatedSensors!=True):
        """ Creating the argparse """
        parser = argparse.ArgumentParser(description = 'Control file for the robot. Needs a COM port to access.')
        parser.add_argument('com', type = str, help = 'set the COM port' )
        parser.add_argument('-t','--twelve_mods' , help = 'use this if you want to initialize 12 controllers/moduals (default is 6)', action = 'store_true')
        parsed = parser.parse_args()


        """ Initializes the variable for the queue of messages that are being sent 'down'. """
        send_down = queue.Queue()

        """
        Creates the array of controllers (currently only 6 or 12)
        """
        global controllers
        controllers = [
            Controller(1,  0x1111, 4),
            Controller(2,  0x2222, 4),
            Controller(3,  0x3333, 4),
            Controller(4,  0x4444, 4),
            Controller(5,  0x5555, 4),
            Controller(6,  0x6666, 4),
        ]
        if parsed.twelve_mods:
            controllers.extend(
                [Controller(7,  0x7777),
                 Controller(8,  0x8888),
                 Controller(9,  0x9999),
                 Controller(10, 0xAAAA),
                 Controller(11, 0xBBBB),
                 Controller(12, 0xCCCC),]
            )

        sm = threading.Thread(target =state_manager.state_manager_process, args = [parsed.com, send_down, controllers])
        sm.daemon = True
        sm.start()

        #Ensure commucation between Xbees is established
        Xbee_ready = False
        while(Xbee_ready==False):
            Xbee_ready = True
            print("Requesting echoes...")
            for c in controllers:
                m = mw.write_echo(c, c.get_echo() + 1)
                c.start_echo()
                send_down.put([c, m])
                time.sleep(.05)
            time.sleep(2) # wait 2s for replies
            for c in controllers:

                #print(str(c.get_id())+': '+ str(c.connected))
                #if c.connected==False:
                    #Xbee_ready = False 

       

                if c.connected==False:
                    Xbee_ready = False        

    
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

        
    
