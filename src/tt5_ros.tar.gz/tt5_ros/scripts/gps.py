#!/usr/bin/env python
import numpy as np
import rospy
from std_msgs.msg import String
from tt5_ros.msg import SixRodOrientation
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders
from tt5_ros.msg import SixRodMotorCommands

import control

def acceleration_callback(data):
    x = 5
    print(data)
    print('MAP GPS COMMANDS TO CORRECT FORMAT')
    print('SEND COMMANDS TO XBEE TO EXECUTE')



    # msg = [0,0,0,0]
    # message = mw.write_motor_command(msg)
    # print(c,message, '     c, message')
    # send_down.put([c, message])



    # GPS.update(data)
    ### PASS ACCELERATION DATA BACK TO GPS


def listener():

    rospy.init_node('Master_Side_Listener', anonymous=True)
    rospy.Subscriber('Accelerations', SixRodAcceleration, acceleration_callback)
    print('gps subscribed')
    

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
