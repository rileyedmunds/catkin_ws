#!/usr/bin/env python
#imports needed from gps
import copy
import numpy as np
import scipy.ndimage as sp_ndimage
import roslib; roslib.load_manifest('gps_agent_pkg')
import rospy
import time
import threading
import pickle
import os
import argparse
from scipy import io
from std_msgs.msg import String, Float32, UInt16, Float32MultiArray
from sensor_msgs.msg import Imu


FLANN_DIR = os.environ['FLANN_PATH']
SUPERBALL_BAR_ACCELERATIONS = 0
TT4_BAR_ACCELERATIONS = 1
MOTOR_POSITIONS = 2
ACTION = 3



SUPERBALL_SENSOR_DIMS = {
    MOTOR_POSITIONS: 12,
    SUPERBALL_BAR_ACCELERATIONS: 36,
    ACTION: 12,
    BAR_MIDPOINT_POSITIONS:18,
    BAR_MIDPOINT_ACCELERATIONS: 18,
    TT4_BAR_ACCELERATIONS:6,

}

HYPERPARAMS = {
    # 'state_estimator': True,
    'dt': 0.1,
    'T': 50,
    'sensor_dims': SUPERBALL_SENSOR_DIMS,
    'smooth_noise': True,
    'smooth_noise_renormalize': True,
    'smooth_noise_var': 2.0,
    'constraint': True,
    'constraint_file': FLANN_DIR + 'l0_filtered_2016_01_21_09_53_29.npy',
    'constraint_params': {
        'index_file': FLANN_DIR + 'index_filtered_2016_01_21_09_53_29_manhattan.flann',
        'distance_type': 'manhattan',
    },
    'ctrl_vel': False,
    'sensors_dropout_rate': 0.03,
    'sensors_noise_stdddev': 0.05,
}

def generate_noise(T, dU):
    """
    Generate a T x dU gaussian-distributed noise vector. This will
    approximately have mean 0 and variance 1, ignoring smoothing.
    Args:
        T: Number of time steps.
        dU: Dimensionality of actions.
    Hyperparams:
        smooth: Whether or not to perform smoothing of noise.
        var : If smooth=True, applies a Gaussian filter with this
            variance.
        renorm : If smooth=True, renormalizes data to have variance 1
            after smoothing.
    """
    smooth, var = True, 1
    renorm = True
    noise = np.random.randn(T, dU)
    if smooth:
        # Smooth noise. This violates the controller assumption, but
        # might produce smoother motions.
        for i in range(dU):
            noise[:, i] = sp_ndimage.filters.gaussian_filter(noise[:, i], var)
        if renorm:
            variance = np.var(noise, axis=0)
            noise = noise / np.sqrt(variance)
    return noise

class AgentSUPERball(object):
    """
    All communication between the algorithms and the SUPERball simulation is done through this class.
    """
    def __init__(self):
        self._init_obs()
        config = copy.deepcopy(HYPERPARAMS)
        self._hyperparams = config

        if self._hyperparams['constraint']:
            import superball_kinematic_tool as skt
            self._constraint = skt.KinematicMotorConstraints(
                self._hyperparams['constraint_file'], **self._hyperparams['constraint_params']
            )
        rospy.init_node('superball_agent', disable_signals=True, log_level=rospy.DEBUG)

        self._obs_update_lock = threading.Lock()
        self._motor_pos_sub = rospy.Subscriber(
            '/ranging_data_matlab', Float32MultiArray,
            callback=self._motor_pos_cb, queue_size=1
        )
        self._imu_sub = []
        for i in range(12):
            self._imu_sub.append(
                rospy.Subscriber(
                    SUPERBALL_IMU_TOPICS[i], Imu,
                    callback=self._imu_cb, queue_size=1
                )
            )

        self._ctrl_pub = rospy.Publisher('/superball/control', String, queue_size=1)
        self._timestep_pub = rospy.Publisher('/superball/timestep', UInt16, queue_size=1)
        self._init_motor_pubs()
        self._run_sim = False
        self._sim_thread = threading.Thread(target=self._continue_simulation)
        self._sim_thread.daemon = True
        self._sim_thread.start()
        self._action_rate = rospy.Rate(10)

    def _continue_simulation(self):
        rate = rospy.Rate(10)
        while True:
            # if self._run_sim:
            self._timestep_pub.publish(UInt16(100))
            # time.sleep(0.099)
            rate.sleep()




    def _imu_cb(self, msg):
        with self._obs_update_lock:
            if not np.isnan(msg.linear_acceleration.y):
                i = [int(n) for n in msg.header.frame_id.split() if n.isdigit()]
                index = i[0] - 1
                if index % 2 == 0:
                    index += 1
                else:
                    index -=1
                self._sensor_readings[SUPERBALL_BAR_ACCELERATIONS][index] = msg.linear_acceleration.y


    def _init_motor_pubs(self):
        self._motor_pubs = []
        for i in range(12):
            if i % 2 == 0:
                bbb, board_id, sub_index = i + 2, 0x71, 0x2
            else:
                bbb, board_id, sub_index = i + 1, 0x1, 0x1
            self._motor_pubs.append(
                    rospy.Publisher('/bbb%d/0x%x_0x2040_0x%x' % (bbb, board_id, sub_index), Float32,
                        queue_size=1))

    def _init_obs(self):
        self._sensor_readings = {TT4_BAR_ACCELERATIONS: np.zeros(6)}

    @property
    def obs(self):
        return self._sensor_readings[TT4_BAR_ACCELERATIONS]

    def sample(self, policy, horizon):
        self._init_obs()
        self.relax()

        # noise = np.zeros_like(generate_noise(horizon, 12))
        noise = generate_noise(horizon, 12)
        self._run_sim = True
        for t in range(horizon):
            obs_t = self.obs
            # if t < 10:
            print obs_t
            U_t = policy.act(np.zeros_like(obs_t), obs_t, t, noise[t,:])
            self._set_motor_positions(U_t)
            self.advance_simulation()

        self._run_sim = False

    def _set_motor_positions(self, pos):
        gain = 1 / 0.009
        msg = Float32()
        if not USE_F32:
            msg.header.stamp = rospy.rostime.get_rostime()
        if (pos - 0.95).all() and self._hyperparams['constraint']:
            pos = self._constraint.find_nearest_valid_values(pos)
        for i in range(12):
            # msg.data = (0.95 - pos[i]) / 0.009
            if END_CAP_6_DOWN:
                if i == 6:
                    continue
            msg.data = min(max(7.5, ((0.95 - pos[i]) * gain) + (7.5 / gain)), 45)
            self._motor_pubs[i].publish(msg)

    def relax(self):
        # print 'Relaxing'
        self._set_motor_positions(np.ones(12) * 0.95)
        self.advance_simulation(30)
        # print "Press enter to continue"
        # raw_input()
        # print 'Relaxed!'

    def reset(self, bottom_face=0):
        rospy.set_param('/bottom_face', bottom_face + 1)
        self._ctrl_pub.publish(String('reset'))

    def advance_simulation(self, step=1):
        for _ in xrange(step):
            # self._timestep_pub.publish(UInt16(100))
            # time.sleep(0.095)
            # time.sleep(0.01)
            self._action_rate.sleep()

    def replay_actions(self, actions):
        for t in range(actions.shape[0]):
            obs_t = self.obs
            # if t < 10:
            print obs_t
            U_t = actions[t, :]
            self._set_motor_positions(U_t)
            self.advance_simulation()



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Run caffe policy.')
    parser.add_argument('policy', type=str, help='pickled policy')
    parser.add_argument('-t', '--timesteps', metavar='N', type=int, default=1000,
                        help='number of time steps')
    parser.add_argument('-r', '--replay', action='store_true', help='replay actions')
    args = parser.parse_args()

    with open(args.policy) as fin:
        policy = pickle.load(fin)

    agent = AgentSUPERball()
    agent.reset()
    agent.relax()
    if args.replay:
        agent.replay_actions(policy)
    else:
        policy = policy.policy_opt.policy
        agent.sample(policy, args.timesteps)

import rospy
from std_msgs.msg import String
from tt5_ros.msg import SixRodMotorCommands
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders
from tt5_ros.msg import MotorCommands
import sys
import threading
import argparse #used to get the COM port and the number of motors
try:
    import Queue as queue
except:
    import queue
import time

#next lines are needed so that the wireless library can be imported from relative path
import os
#direct path of this python file needs to be explicitly defined, so rosrun can be called from any directory 
dir_path = os.path.dirname(os.path.realpath(__file__))
import sys
# sys.path.append(dir_path+'/../../../../wireless/lib/tensegrity_wireless/py')
sys.path.append('/home/jianlan//Spherical-Tensegrity/wireless/lib/tensegrity_wireless/py/')
from controller import Controller
import control
import message_writer as mw
import state_manager
import serial
try:
    import Queue as queue
except:
    import queue

last_line = ''
SimulatedSensors = False
controllers = control.get_controllers()
#send_down = queue.Queue()

def talker():

    rospy.init_node('talker', anonymous=True)
    
    #rod orientation 

    # orientation_pub = rospy.Publisher('Rod_Orientations', SixRodOrientation, queue_size=1000)
    #rod accelerations
    acceleration_pub = rospy.Publisher('Accelerations', SixRodAcceleration, queue_size=1)
    # motor commands
    motor_pub = rospy.Publisher('Motor_Commands', SixRodMotorCommands, queue_size=1)
    #rod encoders
    # encoder_pub = rospy.Publisher('Encoders', SixRodEncoders, queue_size=1000)

    
    rate = rospy.Rate(10) # 10hz

    #continuously update and publish
    while not rospy.is_shutdown():

        Acceleration_Vec = update_Accelerations()
        acceleration_pub.publish(Acceleration_Vec)

        Motor_Commands_Vec = update_Motors()
        motor_pub.publish(Motor_Commands_Vec)
        
        rate.sleep()

############################################################################


def keep_last_line():
    global last_line, new_line_event
    for line in sys.stdin:
        #need 'last_line' for each sensor group
        #last_line emulates the state_managers latest readings
        if 'Simulated_Orientation_Sensors' in line:
            last_line = line
        
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def update_Accelerations():
    Acceleration_Vec = SixRodAcceleration()
    # measurements = control.get_encoder_reading()
    for c in controllers:
        rod_num = str(c.get_id())
        rod_accel = getattr(Acceleration_Vec,'rod'+rod_num)
        [rod_accel.x,rod_accel.y,rod_accel.z] = c.get_imu()
    print(Acceleration_Vec, '      =acceleration vec')    
    return Acceleration_Vec

def update_Motors():
    motor_vec = SixRodMotorCommands()
    commands = [0]*24 ### GET COMMANDS FROM GPS
    motor_command = SixRodMotorCommands()
    rods = [
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        MotorCommands(),
        ]
    for i in range(len(rods)):
        rod = rods[i]
        rod.motor1 = commands[4 * i]
        rod.motor2 = commands[4 * i + 1]
        rod.motor3 = commands[4 * i + 2]
        rod.motor4 = commands[4 * i + 3]
        setattr(motor_command, 'rod' + str(i+1), rod)
    return motor_command

if __name__ == '__main__':
    print('Starting Xbee-side ROS node...')

    if(SimulatedSensors!=True):

        """ Initializes the variable for the queue of messages that are being sent 'down'. """
        # send_down = control.get_send_down()
        global send_down
        sm, send_down = control.get_sm_queue()

        #Ensure commucation between Xbees is established
        Xbee_ready = False
        while(Xbee_ready==False):
            Xbee_ready = True
            print("Requesting echoes...")
            for c in controllers:
                m = mw.write_echo(c.get_echo() + 1)
                c.start_echo()
                send_down.put([c, m]) ###THIS LINE CAUSING THE __TRUNC__ ERROR
                time.sleep(.05)


                msg = [0,0,0,0]
                message = mw.write_motor_command(msg)
                print(c,message, '     c, message')
                send_down.put([c, message])

                time.sleep(.05)


            time.sleep(2) # wait 2s for replies
            for c in controllers:

                print(str(c.get_id())+': '+ str(c.connected))
                if c.connected==False:
                    Xbee_ready = True        

    try:
        talker()
    except rospy.ROSInterruptException:
        pass

        
    
