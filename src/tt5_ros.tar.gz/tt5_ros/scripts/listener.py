#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from tt5_ros.msg import SixRodOrientation
from tt5_ros.msg import SixRodAcceleration
from tt5_ros.msg import SixRodEncoders

def callback1(data):
    rospy.loginfo(rospy.get_caller_id() + ' I heard %s', data)

def callback2(data):
    rospy.loginfo(rospy.get_caller_id() + ' I heard %s', data)

def callback3(data):
    rospy.loginfo(rospy.get_caller_id() + ' I heard %s', data)

def listener():

    rospy.init_node('Master_Side_Listener', anonymous=True)

    rospy.Subscriber('Encoders', SixRodEncoders, callback1)
    rospy.Subscriber('Rod_Orientations', SixRodOrientation, callback2)
    rospy.Subscriber('Accelerations', SixRodAcceleration, callback3)
    

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()
